from .basenet import BaseNet
from .resnet import ResNet18
from .QuizDNN import QuizDNN
